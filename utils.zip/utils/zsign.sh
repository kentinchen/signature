#!/bin/bash

zsign -f -k $1 -p 123 -m $2 -o $3 $4
