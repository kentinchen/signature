1.对windows10这种权限要求严格的，请右击后选择  使用管理员权限运行ausign_gui.exe,
  win7可以直接双击运行
2.linux 和mac需要安装java jre 8 或者jdk 8以上版本 下载地址 www.java.com/download
3.ausign.exe是命令行版本
4.软件不支持32位操作系统
5.可以加群946505735了解及时动态，那样可以常上官网http://s.kxapp.com下载最新版本
