#!/bin/bash

ausign -sign $1 -c $2 -m $3 -p 123